function _1(md){return(
md`# Assignment 4: Graduated Symbol Mapping
Obesity in Illinois`
)}

function _graduatedSymbols(d3,width,height,radiusArray,Yl0rRd,circleLabelText,topojson,basepolygons,path_basemap,points,finalAttributeName,path_points,radius,colors,idName,format)
{
  const svg = d3.create("svg")
                .attr("viewBox", [0, 0, width, height]);

  svg.append("text").attr("x", 0).attr("y", 14).attr("font-weight", 400).text('Adult Obesity in Illinois');

  // Legend group
  const legendGroup = svg.append("g");
  const gap = 80; // distance between each legend item
  const x0 = 10;
  const y = 55;

  const xs = [];
  let cx = x0 + radiusArray[0];
  xs.push(cx);
  for (let i = 1; i < radiusArray.length; i++) {
    cx = cx + radiusArray[i - 1] + gap + radiusArray[i];
    xs.push(cx);
  }
  // Circles
  legendGroup.selectAll("circle")
    .data(radiusArray)
    .join("circle")
      .attr("cx", (r, i) => xs[i])
      .attr("cy", y)
      .attr("r", r => r)
      .attr("fill", (r, i) => Yl0rRd[i])
      .attr("fill-opacity", 0.8)
      .attr("stroke", "black")
      .attr("stroke-width", 0.5);
  // Labels
  legendGroup.selectAll("text.legend-label")
    .data(circleLabelText)
    .join("text")
      .attr("class", "legend-label")
      .attr("x", (d, i) => xs[i] + radiusArray[i] + 6) // right of circle
      .attr("y", y + 4)                                // baseline tweak
      .attr("font-size", 11)
      .text(d => d);

  // Map group
  const mapGroup = svg.append("g")
                      .attr("transform", 'translate(10, 50)');
 
  mapGroup.append("path")
     .datum(topojson.feature(basepolygons, basepolygons.objects.IL_counties_wgs84)) // create one SVG element based on the TopoJSON feature in comparison with the .data().join() that we use in the choropleth map
     .attr("fill", "#ccc")
     .attr("d", path_basemap);
  
  mapGroup.append("path")
    .datum(topojson.mesh(basepolygons, basepolygons.objects.IL_counties_wgs84, (a, b) => a !== b)) // convert the TopoJSON to line feature with topojson.mesh()
    .attr("fill", "none")
    .attr("stroke", "black")
    .attr("stroke-linejoin", "round")
    .attr("stroke-width", 0.25)
    .attr("d", path_basemap);

  mapGroup.append("g")
  .selectAll("circle")
  .data(points.features
  .map(d => (d.value = (d.properties[finalAttributeName]), d))
  .sort((a, b) => b.value - a.value))
  .join("circle")
    .attr("transform", d => `translate(${path_points.centroid(d)})`)
    .attr("r", d => radius(d.value))
    .attr("fill", d => colors(d.value))
    .attr("fill-opacity", 1)
    .attr("stroke", "black")
    .attr("stroke-width", 0.5)
    .append("title")
    .text(d => `${d.properties[idName]} : ${format(d.properties[finalAttributeName])}`);
  return svg.node();
}


function _3(md){return(
md`## Markdown: Map Analysis
As far as the spatial distribution of values go, the lowest values are found in the areas with the highest population density, the Chicago metro area and into the surrounding suburbs. The outliers to this trend can be found in Chanpaign and Coles counties, which have college towns and obesity rates lower than surrounding counties. The rural areas have higher values on average, but the region with the highest values are in south central Illinois. The Chicago metro having a cluster of low values makes sense because obesity, in general, decreases in more urbanized areas. The highest concentration of counties with the highest rates of obesity are found along Illinois's borders with Indiana and Wisconsin.`
)}

function _4(md){return(
md`### Q3: How do you determine the style, width, and color of symbol outlines?
The width and color of symbol outlines in a graduated symbol map are added as separate attributes (stroke-width and stroke, respectively). In terms of width, the circles on this specific map have black outlines 0.5 units wide, which I believe is the optimal width for such symbols. The 'stroke-width' attribute is used to specify how wide the circle outlines should be. When it comes to color, the 'fill' tool is used along with the specified color scheme. `
)}

function _5(md){return(
md`### Q4: How do you determine the type of point symbol (e.g., circle, square)?
The legendgroup.selectAll is how to specify circles as the symbol for this type of map, which is the same line of code used for creating a legend. The difference is that "circles" are set as the attribute to be selected. `
)}

function _6(md){return(
md`### Q6: How do you create a legend? 
Creating the legend requires using the legendgroup.selectall function. In this case, the selectAll function was written to create circles. The radiusArray code below that determines circle size is placed within the legend creation code to ensure that the legend shows the correct circle sizes. `
)}

function _7(md){return(
md`### Q7: How are attribute values displayed when hovering over each point?
The '.text' attribute is used to see the name and point value of the county you are hovering over. This attribute requires the unique identifier and the final attribute name using the 'd.properties' function. In the case of this assignment, the unique identifier is each county name.`
)}

function _margin(){return(
50
)}

function _height(){return(
700
)}

function _width(){return(
1000
)}

function _path_points(d3,projection){return(
d3.geoPath().projection(projection)
)}

function _path_basemap(d3,projection){return(
d3.geoPath().projection(projection)
)}

function _projection(d3,margin,width,height,basefeatures){return(
d3.geoAlbers().fitExtent([[margin, margin], [width - margin, height - margin]], basefeatures)
)}

function _format(d3){return(
d3.format(".1f")
)}

function _15(radius){return(
radius(10)
)}

function _radius(d3,breaks,radiusArray){return(
d3.scaleThreshold()
  .domain(breaks)
  .range(radiusArray)
)}

function _colors(d3,breaks,Yl0rRd){return(
d3.scaleThreshold()
  .domain(breaks)
  .range(Yl0rRd)
)}

function _meanArray(breaksMinMax){return(
breaksMinMax.slice(0, -1).map((currentValue,index)=> (currentValue + breaksMinMax[index+1]) / 2)
)}

function _radiusArray(breaksMinMax)
{
  // use the mean of each class as a representative value for each class
  const meanArray = breaksMinMax.slice(0, -1).map((currentValue,index)=> (currentValue + breaksMinMax[index+1]) / 2);
  // calculate radius for each class based on mathematical scaling Ri = (Vi/Vl)^0.5 * Rl
  const largestCircleRadius = 15;  // define an appropriate radius for the largest circle
  const largestValue = meanArray[meanArray.length-1]
  const radiusArray = meanArray.map((currentValue, index) => +(Math.pow(currentValue/largestValue, 2)*largestCircleRadius).toFixed(2))
  return radiusArray
}


function _20(md){return(
md`### Q5: How do you create a scale that links attribute values to symbol radius?
To link symbol radii to attribute values, you have to specify what each size should look like based on the mean value of each data class. The mean serves as the single value that represents each class of values. The starting point is to specify the radius for the largest class, which is manually set by the user using the 'largestCircleRadius' set as a constant value. Each lower radius is calculated based off of the input for the largest value. `
)}

function _circleLabelText(breaksMinMax,format)
{
  const circleLabelText = [];
  for (let i = 0; i < breaksMinMax.length-1; i++) {
    circleLabelText.push(
      `${format(breaksMinMax[i])} – ${format(breaksMinMax[i+1])}`
    );
  }
  return circleLabelText
}


function _Yl0rRd(){return(
["#ffffcc", "#a1dab4", "#41b6c4", "#225ea8"]
)}

function _23(md){return(
md`### Q2: How do you create and apply colors in Observable? How are values mapped to symbol colors?
Creating color in observable requires using colorbrewer.org to find a color scheme. It is important to ensure that it has the right range of colors for the type of data and the correct number of classes. For example, for ordinal data without an average value, it makes less sense to use a diverging color scheme (i.e. green to red). Each color has a unique code that needs to be installed within a set of brackets, set equal to the name of the color scheme. `
)}

function _breaksMinMax(d3,attribute,breaks){return(
[d3.min(attribute), ...breaks]
)}

function _breaks(d3,attribute,simple)
{
  const k = 4; // define the class number
  const min = d3.min(attribute);
  const max = d3.max(attribute);

  // equal interval
  // const interval = (max - min) / k;
  // const equalBreaks = d3.range(1, k).map(i => +(min + i * interval).toFixed(1));
  // equalBreaks.push(max)
  // return equalBreaks

  // quantile classification
  // const sorted = attribute.slice().sort(d3.ascending);
  // const quantileBreaks = d3.range(1, k).map(i =>
  //   d3.quantile(sorted, i / k)
  // );
  // quantileBreaks.push(max)
  // return quantileBreaks
  
  // natural breaks
  const naturalbreaks = simple.ckmeans(attribute, k).map(v => v.pop())
  return naturalbreaks
}


function _26(Plot,attribute,bins){return(
Plot.plot({
  marks: [
    Plot.rectY(attribute, Plot.binX({y: "count"}, {x: d => d, thresholds: bins})),
    Plot.ruleY([0])
  ]
})
)}

function _bins(Inputs){return(
Inputs.range([0, 20], {step: 1, label: "Bins"})
)}

function _attribute(points,finalAttributeName){return(
Array.from(points.features, d=>(d.properties[finalAttributeName]))
)}

function _29(points){return(
points.features
)}

function _30(normalizationAttribute,points,finalAttributeName,orgAttributeName)
{
  if(normalizationAttribute !== ""){
    points.features.forEach(d => {
        d.properties[finalAttributeName] =
          100 * d.properties[orgAttributeName]/d.properties[normalizationAttribute]
    })
  }
}


function _finalAttributeName(normalizationAttribute,orgAttributeName){return(
(normalizationAttribute && normalizationAttribute.trim() !== "")
  ? (orgAttributeName.endsWith("_std") ? orgAttributeName : orgAttributeName + "_std")
  : orgAttributeName
)}

function _normalizationAttribute(){return(
""
)}

function _orgAttributeName(){return(
"Percent_1"
)}

function _idName(){return(
"County"
)}

function _35(md){return(
md`### Q1: How do you join geometries from a GeoJSON file with attributes from a CSV file? 
Joining geoJSON geometries to CSV attributes requires using an identifying key, such as a county ID or county name. the 'idname' is used to accomplish this task, with the idname being set as the unique identifier from the geojson or CSV file. This is to distiuguish one county/state/region from another, because these values will always differ even if corresponding numerical values are identical. `
)}

function _points(FileAttachment){return(
FileAttachment("IL_centroids_wgs84.geojson").json()
)}

function _basefeatures(topojson,basepolygons){return(
topojson.feature(basepolygons, basepolygons.objects.IL_counties_wgs84)
)}

function _38(md){return(
md`### Q8: How do you create the polygon basemap from TopoJSON and set its symbology?
To create a basemap from topoJSON, the topoJSON has to be transformed into a feature class by importing the polygon data. This requires the 'fileattachment' function. Once the base data is imported, using the topojson.feature functon, the topojson file can be turned into a polygon basemap. the topojson file name has to be specified as the objects to be mapped. Setting the symbology requires the import of geojson centroid file and its transformation into a point file, also with the 'fileattachment' function`
)}

function _basepolygons(FileAttachment){return(
FileAttachment("IL_counties_wgs84@1.json").json()
)}

function _simple(require){return(
require("simple-statistics@7.0.7/dist/simple-statistics.min.js")
)}

function _topojson(require){return(
require("topojson-client@3")
)}

function _d3(require){return(
require("d3@5")
)}

function _43(md){return(
md`## Metadata
This dataset was sourced from the Lake County, IL GIS data portal. It covers the state of Illinois and has a resolution of 0.000000007 US survey feet. It covers data over a period of 7 years, with the dataset first created in 2015 and most recently updated in 2022. No transformations or extra work was necessary to preoare the data as the obesity percentages were already available in the CSV file. Any uncertainty relating to this data comes from the fact that the last update happened four years ago, and the data may be heavily outdated.`
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["IL_counties_wgs84@1.json", {url: new URL("./files/7420c03c45ae0ccd20a3d96f638330534eed6d5e6ea7f1d06b153c26478ddd0a0b7d94c7d375c99a0c819f37e0d3b5090d6c046b371f3c97a195f5231976a1d3.json", import.meta.url), mimeType: "application/json", toString}],
    ["IL_centroids_wgs84.geojson", {url: new URL("./files/0794b4e6cc038a6e9dccef03c01eeefbc07b4bd063cd5e4d96a29d3108b8d1029e1706aff55707718aa86bbf3531f98e9365391777ce27bc53553663731d5545.geojson", import.meta.url), mimeType: "application/geo+json", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer("graduatedSymbols")).define("graduatedSymbols", ["d3","width","height","radiusArray","Yl0rRd","circleLabelText","topojson","basepolygons","path_basemap","points","finalAttributeName","path_points","radius","colors","idName","format"], _graduatedSymbols);
  main.variable(observer()).define(["md"], _3);
  main.variable(observer()).define(["md"], _4);
  main.variable(observer()).define(["md"], _5);
  main.variable(observer()).define(["md"], _6);
  main.variable(observer()).define(["md"], _7);
  main.variable(observer("margin")).define("margin", _margin);
  main.variable(observer("height")).define("height", _height);
  main.variable(observer("width")).define("width", _width);
  main.variable(observer("path_points")).define("path_points", ["d3","projection"], _path_points);
  main.variable(observer("path_basemap")).define("path_basemap", ["d3","projection"], _path_basemap);
  main.variable(observer("projection")).define("projection", ["d3","margin","width","height","basefeatures"], _projection);
  main.variable(observer("format")).define("format", ["d3"], _format);
  main.variable(observer()).define(["radius"], _15);
  main.variable(observer("radius")).define("radius", ["d3","breaks","radiusArray"], _radius);
  main.variable(observer("colors")).define("colors", ["d3","breaks","Yl0rRd"], _colors);
  main.variable(observer("meanArray")).define("meanArray", ["breaksMinMax"], _meanArray);
  main.variable(observer("radiusArray")).define("radiusArray", ["breaksMinMax"], _radiusArray);
  main.variable(observer()).define(["md"], _20);
  main.variable(observer("circleLabelText")).define("circleLabelText", ["breaksMinMax","format"], _circleLabelText);
  main.variable(observer("Yl0rRd")).define("Yl0rRd", _Yl0rRd);
  main.variable(observer()).define(["md"], _23);
  main.variable(observer("breaksMinMax")).define("breaksMinMax", ["d3","attribute","breaks"], _breaksMinMax);
  main.variable(observer("breaks")).define("breaks", ["d3","attribute","simple"], _breaks);
  main.variable(observer()).define(["Plot","attribute","bins"], _26);
  main.variable(observer("viewof bins")).define("viewof bins", ["Inputs"], _bins);
  main.variable(observer("bins")).define("bins", ["Generators", "viewof bins"], (G, _) => G.input(_));
  main.variable(observer("attribute")).define("attribute", ["points","finalAttributeName"], _attribute);
  main.variable(observer()).define(["points"], _29);
  main.variable(observer()).define(["normalizationAttribute","points","finalAttributeName","orgAttributeName"], _30);
  main.variable(observer("finalAttributeName")).define("finalAttributeName", ["normalizationAttribute","orgAttributeName"], _finalAttributeName);
  main.variable(observer("normalizationAttribute")).define("normalizationAttribute", _normalizationAttribute);
  main.variable(observer("orgAttributeName")).define("orgAttributeName", _orgAttributeName);
  main.variable(observer("idName")).define("idName", _idName);
  main.variable(observer()).define(["md"], _35);
  main.variable(observer("points")).define("points", ["FileAttachment"], _points);
  main.variable(observer("basefeatures")).define("basefeatures", ["topojson","basepolygons"], _basefeatures);
  main.variable(observer()).define(["md"], _38);
  main.variable(observer("basepolygons")).define("basepolygons", ["FileAttachment"], _basepolygons);
  main.variable(observer("simple")).define("simple", ["require"], _simple);
  main.variable(observer("topojson")).define("topojson", ["require"], _topojson);
  main.variable(observer("d3")).define("d3", ["require"], _d3);
  main.variable(observer()).define(["md"], _43);
  return main;
}
