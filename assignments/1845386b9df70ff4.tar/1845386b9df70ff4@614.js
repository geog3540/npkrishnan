function _1(md){return(
md`# Assignment 5: Bivariate Mapping

Total Area and % Water Area of California Counties. Data: [CA Open Data]`
)}

function _colors(html,schemes)
{
  const form = html`<form><select name=i>${schemes.map(c => Object.assign(html`<option>`, {textContent: c.name}))}</select> <span style="font-size:smaller;font-style:oblique;">color scheme</output>`;
  form.i.selectedIndex = 1;
  form.oninput = () => form.value = schemes[form.i.selectedIndex].colors;
  form.oninput();
  return form;
}


function _chart(d3,width,height,legend,topojson,polygons,color,data,idAttribute,path,format)
{
  const svg = d3.create("svg")
      .attr("viewBox", [0, 0, width, height]);

  svg.append(legend)
      .attr("transform", "translate(670,250)");

  svg.append("g")
    .selectAll("path")
    .data(topojson.feature(polygons, polygons.objects.CA_Counties_wgs84).features)
    .join("path")
      .attr("fill", d => color(data.get(d.properties[idAttribute])))
      .attr("d", path)
      .attr("stroke-width", 0.5)
      .attr("stroke", "black")
    .append("title")
      .text(d => `${d.properties[idAttribute]}, ${format(data.get(d.properties[idAttribute]))}`);
// Q4: The d.properties function is how to see values when you hover over any county on the map. Adding it as a text attribute gets the information to pop up as text. In this case, the idAttribute, total area in sq km, and percentage of water cover pop up. 
  return svg.node();
}


function _4(md){return(
md`## Markdown (Data Properties)
When it comes to the spatial distribution of values, the counties with high areas and low water cover southeast CA have the highest land areas but the lowest water cover. The counties with low area and high water cover are all clustered around the San Francisco bay, with one outlier in the east due to lake Tahoe. The counties with high area and high water cover are all the counties along the coast outside of the Bay area. The only area with counties that have low area and low water cover are in central eastern CA. Geographically, the presence or absence of one variable does not appear to have an effect on the other one. The counties of CA emcompass all nine values within the bivariate color scheme.  `
)}

function _schemes(){return(
[
  {
    name: "RdBu", 
    colors: [
      "#e8e8e8", "#e4acac", "#c85a5a",
      "#b0d5df", "#ad9ea5", "#985356",
      "#64acbe", "#627f8c", "#574249"
    ]
  },
  {
    name: "BuPu", 
    colors: [
      "#e8e8e8", "#ace4e4", "#5ac8c8",
      "#dfb0d6", "#a5add3", "#5698b9", 
      "#be64ac", "#8c62aa", "#3b4994"
    ]
  },
  {
    name: "GnBu", 
    colors: [
      "#e8e8e8", "#b5c0da", "#6c83b5",
      "#b8d6be", "#90b2b3", "#567994",
      "#73ae80", "#5a9178", "#2a5a5b"
    ]
  },
  {
    name: "PuOr", 
    colors: [
      "#e8e8e8", "#e4d9ac", "#c8b35a",
      "#cbb8d7", "#c8ada0", "#af8e53",
      "#9972af", "#976b82", "#804d36"
    ]
  }
]
)}

function _6(md){return(
md`### Q2: Which colors are used for bivariate mapping in Observable?
Selecting the colors used is important, becuse for a bivariate map with no diverging data values, the colors representing each side should be similar in nature. 

#### Q2b: Explain how to select or construct a bivariate color scheme 
Creating a bivariate color scheme requires the use of colorbrewer.org, which creates color schemes for digital maps. The color scheme is arranged in a 3x3 grid, and the colors need to be selected such that the colors not located in any of the corners merge well with each other. Creating the code for the scheme itself requires each desired scheme to be given a name, and for the code of each color to be written out in a 3x3 grid. The position of each color in the code corresponds to their positions in the legend. `
)}

function _labels(){return(
["low", "", "high"]
)}

function _n(colors){return(
Math.floor(Math.sqrt(colors.length))
)}

function _x(d3,data,n){return(
d3.scaleQuantile(Array.from(data.values(), d => d[0]), d3.range(n))
)}

function _y(d3,data,n){return(
d3.scaleQuantile(Array.from(data.values(), d => d[1]), d3.range(n))
)}

function _path(d3,projection){return(
d3.geoPath().projection(projection)
)}

function _projection(d3,width,height,polygon_features){return(
d3.geoTransverseMercator().rotate([90,0]).fitExtent([[10, 10], [width, height]], polygon_features)
)}

function _polygon_features(topojson,polygons){return(
topojson.feature(polygons, polygons.objects.CA_Counties_wgs84)
)}

function _14(md){return(
md`### Q1: How do you join geometries from a TopoJSON file with attributes from a CSV file?
Joining topoJSON properties and CSV properties requires the use of the topojson.feature function, which turns the topojson into geojson. Doing that allows it to be linked to the corresponding CSV file, which contains all pertinent data values. The geoJSON and CSV can only be linked through a common idetifier, such as a GEOID or county/state/region name, which is what I used for this project. `
)}

async function _data(d3,FileAttachment){return(
Object.assign(new Map(d3.csvParse(await FileAttachment("CA_Counties.csv").text(), ({NAMELSAD, ALAND, AWATER}) => [NAMELSAD, [+[(+ALAND)+(+AWATER)]/1000000, (AWATER)/[(+ALAND)+(+AWATER)]*100]])), {title: [" Total Area (sq km)", "% Water Cover"]})
)}

function _idAttribute(){return(
"NAMELSAD"
)}

function _polygons(FileAttachment){return(
FileAttachment("CA_Counties_wgs84-2.json").json()
)}

function _height(){return(
610
)}

function _width(){return(
875
)}

function _legend(DOM,svg,n,d3,colors,data,labels){return(
() => {
  const k = 24;
  const arrow = DOM.uid();
  return svg`<g font-family=sans-serif font-size=10>
    <g transform="translate(-${k * n / 2},-${k * n / 2}) rotate(-45 ${k * n / 2},${k * n / 2})">
      <marker id="${arrow.id}" markerHeight=10 markerWidth=10 refX=6 refY=3 orient=auto>
        <path d="M0,0L9,3L0,6Z" />
      </marker>
      ${d3.cross(d3.range(n), d3.range(n)).map(([i, j]) => svg`<rect width=${k} height=${k} x=${i * k} y=${(n - 1 - j) * k} fill=${colors[j * n + i]}>
        <title>${data.title[0]}${labels[j] && ` (${labels[j]})`}
        ${data.title[1]}${labels[i] && ` (${labels[i]})`}</title>
      </rect>`)}
      <line marker-end="${arrow}" x1=0 x2=${n * k} y1=${n * k} y2=${n * k} stroke=black stroke-width=1.5 />
      <line marker-end="${arrow}" y2=0 y1=${n * k} stroke=black stroke-width=1.5 />
      <text font-weight="bold" dy="1.5em" transform="rotate(90) translate(${n / 2 * k},6)" text-anchor="middle">${data.title[0]}</text>
      <text font-weight="bold" dy="1.5em" transform="translate(${n / 2 * k},${n * k + 6})" text-anchor="middle">${data.title[1]}</text>
    </g>
  </g>`;
}
)}

function _21(md){return(
md`### Q3: How do you create a bivariate legend?
Creating a bivariate legend, you have to specify the size of each square, the layout, and the font and font size of each zxis label. The fill function has to be used, and the legend has to be filled with the color scheme of choice. Arrows for the bottom boundaries and the angle of orientation has to be manally set, using the const arrow and the rotate function respectively. 

#### Q3b: How do you position the legend so it is not hidden behind the map?
In order to ensure that the legend does not end up behind the map, the location of both the legend and the map have to be set using the transform and translate functions. the height and width of the whole canvas has to be set large enough that both the legend and map can be displayed within. The legend's position should utilize the shape of the map. For example, the map in this assignment was of California. The legend for that map should be placed on the right side because that is where the most open space is. `
)}

function _color(colors,y,x,n)
{
  return value => {
    if (!value) return "#ccc";
    let [a, b] = value;
    return colors[y(b) + x(a) * n];
  };
}


function _formatNum(d3){return(
d3.format(".1f")
)}

function _format(formatNum,data,labels,x,y){return(
(value) => {
  if (!value) return "N/A";
  let [a, b] = value;
  return `${formatNum(a)} ${data.title[0]}${labels[x(a)] && ` (${labels[x(a)]})`}
${formatNum(b)} ${data.title[1]}${labels[y(b)] && ` (${labels[y(b)]})`}`;
}
)}

function _topojson(require){return(
require("topojson-client@3")
)}

function _d3(require){return(
require("d3@5")
)}

function _27(md){return(
md`## Metadata
The data used in this project is sourced from the California Open Data portal. Geographically, it covers the state of California's boundaries and has a spatial resolution of one meter. Its temporal resolution is one neary, with the dataset being created in 2023. The variables given in the CSV file include longitude, latitude, water area, and land area. Creating the bivariate map required normalization of two different variables: total area and % of water cover. For the total area, normalization required adding the land area and water area variables, and dividing that number by 1000000 to get the area in square kilometers. As for the water cover percentage, I had to divide the water cover by the sum of land and water cover (total area) and multiply that result by 100 to get the final fiures as percentages. Both datasets show each normalizee variable on a county basis. This dataset does not appear to have any variable be subject to uncertainty except the water cover variable, which could change due to a shifting climate and changes in weather patterns.`
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["CA_Counties.csv", {url: new URL("./files/d66ecf250971a32dc366de9b0a9e3aa256a1e1090da73793c411b02e156e8184e5feb41f4d6772a8e0c6ed577651ff5662958dd03af48fd44354cf18fd7fde3a.csv", import.meta.url), mimeType: "text/csv", toString}],
    ["CA_Counties_wgs84-2.json", {url: new URL("./files/df690b6de29389ac8822f825bc462e4a3eae22458c35bb8ae02fc56f7af30661c56012d00e5f365169f81e2693694d283e2e6271079d7f456c41ac5089804a36.json", import.meta.url), mimeType: "application/json", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer("viewof colors")).define("viewof colors", ["html","schemes"], _colors);
  main.variable(observer("colors")).define("colors", ["Generators", "viewof colors"], (G, _) => G.input(_));
  main.variable(observer("chart")).define("chart", ["d3","width","height","legend","topojson","polygons","color","data","idAttribute","path","format"], _chart);
  main.variable(observer()).define(["md"], _4);
  main.variable(observer("schemes")).define("schemes", _schemes);
  main.variable(observer()).define(["md"], _6);
  main.variable(observer("labels")).define("labels", _labels);
  main.variable(observer("n")).define("n", ["colors"], _n);
  main.variable(observer("x")).define("x", ["d3","data","n"], _x);
  main.variable(observer("y")).define("y", ["d3","data","n"], _y);
  main.variable(observer("path")).define("path", ["d3","projection"], _path);
  main.variable(observer("projection")).define("projection", ["d3","width","height","polygon_features"], _projection);
  main.variable(observer("polygon_features")).define("polygon_features", ["topojson","polygons"], _polygon_features);
  main.variable(observer()).define(["md"], _14);
  main.variable(observer("data")).define("data", ["d3","FileAttachment"], _data);
  main.variable(observer("idAttribute")).define("idAttribute", _idAttribute);
  main.variable(observer("polygons")).define("polygons", ["FileAttachment"], _polygons);
  main.variable(observer("height")).define("height", _height);
  main.variable(observer("width")).define("width", _width);
  main.variable(observer("legend")).define("legend", ["DOM","svg","n","d3","colors","data","labels"], _legend);
  main.variable(observer()).define(["md"], _21);
  main.variable(observer("color")).define("color", ["colors","y","x","n"], _color);
  main.variable(observer("formatNum")).define("formatNum", ["d3"], _formatNum);
  main.variable(observer("format")).define("format", ["formatNum","data","labels","x","y"], _format);
  main.variable(observer("topojson")).define("topojson", ["require"], _topojson);
  main.variable(observer("d3")).define("d3", ["require"], _d3);
  main.variable(observer()).define(["md"], _27);
  return main;
}
