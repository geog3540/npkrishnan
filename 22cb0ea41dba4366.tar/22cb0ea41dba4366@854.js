import define1 from "./a33468b95d0b15b0@817.js";

function _1(md){return(
md`# Assignment 3: Choropleth Mapping
Water Coverage in California Counties, Source: [California Open Data]`
)}

function _d3(require){return(
require("d3@5")
)}

function _simple(require){return(
require("simple-statistics@7.0.7/dist/simple-statistics.min.js")
)}

function _format(){return(
d => `${d}%`
)}

function _topojson(require){return(
require("topojson-client@3")
)}

function _CA(FileAttachment){return(
FileAttachment("CA_counties2@5.json").json()
)}

function _counties(topojson,CA){return(
topojson.feature(CA, CA.objects.CA_counties2)
)}

async function _csv_data(d3,FileAttachment){return(
d3.csvParse(await FileAttachment("CA_counties2@3.csv").text(),({GEOID, ALAND, AWATER}) => [GEOID, (AWATER)/[(+ALAND)+(+AWATER)]*100])
)}

function _data(csv_data){return(
Object.assign(new Map(csv_data), {title: "Water Area of CA Counties"})
)}

function _11(md){return(
md`Q1: The 'object.assign' function is how topoJSON data and csv data are merged together. The 'object' is located in the topoJSON's code, and the 'assign' function assigns it the CSV data, including any normalized variables not in the original file. Joining the two types of data requires a unique identifier, such as a county name or GEOID, that is specific to each polygon. `
)}

function _12(data){return(
data.get("")
)}

function _pctwater(csv_data){return(
Array.from(csv_data.values(), d => d[1])
)}

function _bluescale(d3){return(
[d3.color("#eff3ff"), d3.color("#bdd7e7"), d3.color("#6baed6"), d3.color("#3182bd"),d3.color("#08519c")]
)}

function _naturalbreaks(simple,pctwater,bluescale){return(
simple.ckmeans(pctwater, bluescale.length).map(v => v.pop())
)}

function _16(md){return(
md`This classification scheme contains 5 classes using the natural breaks method. The breakpoints between classes are 4.39, 10.87, 18.17, 39.45, and 79.77. The reason the classification scheme has such attributes is the data distribution. Most counties have water coverage that falls within the first 2 columns of the histogram from assignment 2. Since the data is heavily skewed, with minimal values in the higher ranges, using a classification where the values per class or interval are identical would not make sense. `
)}

function _color(d3,naturalbreaks,bluescale){return(
d3.scaleThreshold()
  .domain(naturalbreaks)
  .range(bluescale)
)}

function _width(){return(
250
)}

function _height(){return(
300
)}

function _margin(){return(
5
)}

function _projection(d3,margin,width,height,counties){return(
d3.geoTransverseMercator().rotate([120,0]).fitExtent([[margin, margin], [width, height]], counties)
)}

function _path(d3,projection){return(
d3.geoPath().projection(projection)
)}

function _choropleth(d3,width,height,legend,color,data,counties,path)
{
  const svg = d3.create("svg")
      .attr("viewBox", [0, 0, width, height]);

  svg.append("g")
      .attr("transform", "translate(110,10)")
      .append(() => 
              legend({
                  color: color,
                  title: data.title,
                  width: 100,
                  tickFormat: ".1f"
                  })
             );
//Q4: To create a legend for your map, you need to use the 'legend' code block attached to the .append function. It requires a predefined color scheme, a title defined in the 'data' line of code, a width relative to your map, and the number of decimal places using the tickformat function. The width should not exceed half of the map's width, but should be wide enough that all of the class breaks are discernible from each other. It is optimally placed when centered at the top of the map. The 'transform' attribute specifies where the legend should be placed laterally, with higher numbers indicating placement farther to the right. The 'translate' attribute specifies where it goes vertically, with higher numbers placing the legend further down. For example, the (150, 0) used for this map means that it is 150 units across and 0 down, or at the very top of the map.
  svg.append("g")
    .selectAll("path")
    .data(counties.features)
    .join("path")
      .attr("stroke", "black")
      .attr("stroke-linejoin", "round")
      .attr("stroke-width", 0.25)
//Q3: Polygon borders are determined by the values associated with the "stroke" and "stroke-width" attributes. For example, in this assignment, I used black for my polygon borders, 0.25 units wide, because most polygons in my dataset are light in color, with exceptions. For a polygon map, the outline color should contrast with the polygon color. The lines should also be thin enough not to obstruct the polygons themselves, which can happen if the stroke width is greater than 2 and the polygons are small.  
      // .attr("fill", function(d){
      //     console.log(color(data.get(d.properties.GEOID)[0]))
      //     return color(data.get(d.properties.GEOID)[0]);
      // })
      .attr("fill", d => color(data.get(d.properties.GEOID)))
//Q2: You add color to a map in Observable using the 'fill' attribute. Using the 'data' and 'color' codes, each polygon is assigned the correct color based on the color scheme and its data value. The 'color' line of code contains the domain and range. The domain is, for instance, the natural breaks code that contains the variable and the number of colors in the color scheme. The range contains the actual colors that make up the color scheme. The placement of the colors is achieved using the (d.properties.GEOID) code, which adds colors based on each polygon's properties, with GEOID as the unique identifier.
      .attr("d", path)
      .append("title")
      .text(d => " Water Cover: " + data.get(d.properties.GEOID));
//Q5: The '.text' function is what allows you to hover the cursor over each polygon to see its associated value. Like in Q2, the task itself is done via the (d.properties) function. It uses the same block of code as the "fill" function, which assigns each polygon the correct color from the color scheme. The title shown above is displayed along with the variable associated with that polygon. For instance, when I hover over LA County, it tells me that the county has a water area of 14.57%.
  return svg.node();
}


function _24(md){return(
md`Spatial Data Properties
1. In terms of the spatial distribution, all of the highest values are overwhelmingly found in all of California's counties that touch the Pacific Ocean. This goes double for counties that possess islands off the coast. 
2. The two largest clusters in terms of counties per cluster are in the Bay Area (San Francisco and San Mateo counties) and the Los Angeles area (Santa Barbara County). The only non-coastal cluster is found in the two counties around Lake Tahoe, in the eastern part of the state (Placer and El Dorado counties). The only real outlier is Modoc County, in the far Northeast. Modoc County is one of only two counties with water coverage over 6% that lack a massive lake. Rather, it contains a few smaller lakes and is not large in area, hence the higher than expected percentage.
3. The reason that the distribution looks the way it does is because of proximity to the ocean. The counties in the North surround the San Francisco Bay, which is why San Francisco and San Mateo counties have the highest % of water cover. `
)}

function _25(data){return(
data.get
)}

function _26(color,data){return(
color(data.get())
)}

function _27(color){return(
color(40)
)}

function _28(md){return(
md`Metadata
1. I obtained this dataset from (https://data.ca.gov/dataset/ca-geographic-boundaries). This dataset covers California's counties and has a 30-meter resolution, displayed with a WGS84 Geographic Coordinate System. The dataset was initially created in 2019 and updated most recently in 2024.
2. To transform the data, I had to change the coordinate system of the shapefile to WGS 84 so it could be displayed as a choropleth map in Observable. To create my normalized variable, I divided the water area by the sum of the water and land areas, then multiplied the result by 100 to get the water area as a percentage of the total area.
3. The only errors that could be a problem are county coastlines, by which I mean the demarcation of where the coastline is may not be fully accurate. This also goes for the county borders around the SF Bay. The bay itself is not shown on the map, and it is unclear which source they used to delineate each county's bay territory. Water borders are harder to specify and show on a digital map than land borders.`
)}

function _ca_counties25(FileAttachment){return(
FileAttachment("CA_counties2@5.json").json()
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["CA_counties2@5.json", {url: new URL("./files/ecc8c4ddda03eac0f7e60832f2b54d45a8931c4c7c202aa737936033e512b110c4e48d1b79e04746365154d8bac8b8d5a7dffbf3b2cd18800f151cf3cc56e87a.json", import.meta.url), mimeType: "application/json", toString}],
    ["CA_counties2@3.csv", {url: new URL("./files/d7a608e6356285a12327454a994faeac003004d258a22c79f6e39ddb70c18f871147b7f1dc9251c5d717b7d080a9a239b7867602c1d4a7a486ccec22499a1aeb.csv", import.meta.url), mimeType: "text/csv", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer("d3")).define("d3", ["require"], _d3);
  const child1 = runtime.module(define1);
  main.import("legend", child1);
  main.variable(observer("simple")).define("simple", ["require"], _simple);
  main.variable(observer("format")).define("format", _format);
  main.variable(observer("topojson")).define("topojson", ["require"], _topojson);
  main.variable(observer("CA")).define("CA", ["FileAttachment"], _CA);
  main.variable(observer("counties")).define("counties", ["topojson","CA"], _counties);
  main.variable(observer("csv_data")).define("csv_data", ["d3","FileAttachment"], _csv_data);
  main.variable(observer("data")).define("data", ["csv_data"], _data);
  main.variable(observer()).define(["md"], _11);
  main.variable(observer()).define(["data"], _12);
  main.variable(observer("pctwater")).define("pctwater", ["csv_data"], _pctwater);
  main.variable(observer("bluescale")).define("bluescale", ["d3"], _bluescale);
  main.variable(observer("naturalbreaks")).define("naturalbreaks", ["simple","pctwater","bluescale"], _naturalbreaks);
  main.variable(observer()).define(["md"], _16);
  main.variable(observer("color")).define("color", ["d3","naturalbreaks","bluescale"], _color);
  main.variable(observer("width")).define("width", _width);
  main.variable(observer("height")).define("height", _height);
  main.variable(observer("margin")).define("margin", _margin);
  main.variable(observer("projection")).define("projection", ["d3","margin","width","height","counties"], _projection);
  main.variable(observer("path")).define("path", ["d3","projection"], _path);
  main.variable(observer("choropleth")).define("choropleth", ["d3","width","height","legend","color","data","counties","path"], _choropleth);
  main.variable(observer()).define(["md"], _24);
  main.variable(observer()).define(["data"], _25);
  main.variable(observer()).define(["color","data"], _26);
  main.variable(observer()).define(["color"], _27);
  main.variable(observer()).define(["md"], _28);
  main.variable(observer("ca_counties25")).define("ca_counties25", ["FileAttachment"], _ca_counties25);
  return main;
}
